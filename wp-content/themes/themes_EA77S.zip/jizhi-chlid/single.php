<?php
	$sidebar = cao_sidebar();
	$column_classes = cao_column_classes( $sidebar );
	get_header();
?>
<!--顶部标题-->
	<section class="article-focusbox bgimg-fixed lazyloaded" style="background: linear-gradient(90deg,#05e6aa,#1cbdf9);">
	<div class="container">
	    <header class="article-header">
	        <h1 class="article-title"><?php echo get_the_title(); ?></h1>
	        <div class="article-meta">
	            <span class="item"><i class="fa fa-clock-o"></i>  <?php echo date("Y-m-d",strtotime($post->post_date));?></span>
	            <span class="item"><i class="fa fa-user-plus"></i>  <?php echo get_userdata(get_post()->post_author)->nickname;?></span>
				<span class="item"><i class="fa fa-navicon"></i>   <?php $category = get_the_category(); echo $category[0]->cat_name; ?></span>
				<span class="item"><i class="fa fa-eye"></i>   <?php echo _get_post_views() ?></span>
				
				<span class="item"><a target="_blank" title="点击查看" rel="external nofollow" href="https://www.baidu.com/s?wd=<?php echo get_the_title(); ?>_<?php bloginfo('name'); ?>"><i class="fa fa-paw"></i>  已收录</a></span>
	        </div>
	    </header>
    </div>
</section>
<div class="dabolang mobile-hide"> 
		<div id="dabolangl1" class="dabolangl"></div> 
		<div id="dabolangl2" class="dabolangl"></div> 
		<div id="dabolangl3" class="dabolangl"></div>
</div>

<!--顶部标题-->
<div class="container">

	<div class="breadcrumbs">
	<?php echo dimox_breadcrumbs(); ?>
	</div>
	<div class="row">
		<div class="<?php echo esc_attr( $column_classes[0] ); ?>">
			<div class="content-area">
				<main class="site-main">
					<?php while ( have_posts() ) : the_post();
						get_template_part( 'parts/template-parts/content', 'single' );
					endwhile; ?>
				</main>
			</div>
		</div>
		<?php if ( $sidebar != 'none' ) : ?>
			<div class="<?php echo esc_attr( $column_classes[1] ); ?>">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php if (_cao('disable_related_posts','1') && _cao('related_posts_style','grid')=='fullgrid') {
	get_template_part( 'parts/related-posts' );
}?>

<?php get_footer(); ?>