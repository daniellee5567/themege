<?php

$mode_tagpost = _cao('mode_tagpost');



foreach ($mode_tagpost['tagcms'] as $key => $cms) { 

	$args = array(
	    'tag'            => $cms['tag'],
	    'ignore_sticky_posts' => true,
	    'post_status'         => 'publish',
	    'posts_per_page'      => $cms['count'],
	    'orderby'      => $cms['orderby'],
	);

	///////////S CACHE ////////////////
	if (CaoCache::is()) {
	     $clean_string = preg_replace('/[^A-Z]/i', '', $args['tag']);
	    $_the_cache_key = 'ripro_home_tagpost_posts_'.$clean_string;
	    $_the_cache_data = CaoCache::get($_the_cache_key);
	    if(false === $_the_cache_data ){
	        $_the_cache_data = new WP_Query($args); //缓存数据
	        CaoCache::set($_the_cache_key,$_the_cache_data);
	    }
	    $data = $_the_cache_data;
	}else{
	    $data = new WP_Query($args); //原始输出
	}
	///////////S CACHE ////////////////
	 ?>
	<div class="section pb-0">
	  <div class="container">
	  	<h3 class="section-title">
	  		<span><a href="<?php echo $cms['wholelink']; ?>"><?php echo $cms['wholename']; ?></a></span>
	  		<i class="category-num"><?php echo $data->found_posts;?></i>
	  	</h3>
	  	<li class="zhankr-syli"><?php echo $cms['wholedesc']; ?></li>
	  	<!--云创源码网CMS菜单-->
	  	<?php
		$tag_slugs = explode(',', $cms['tag']);
		$tag_slugs = array_map('trim', $tag_slugs);
		$tax_terms = get_terms(array(
		    'taxonomy' => 'post_tag', // 或者使用 'tag'
		    'slug'     => $tag_slugs,
		    'hide_empty' => false,    // 是否包含空标签
		));
		
		if(!empty($tax_terms)){?>
		<div class="choosetype">
		<?php foreach ($tax_terms as $subtag ) {  ?>
			
			<a href="<?php echo esc_url(get_term_link($subtag)); ?>" target="_blank"><?php echo esc_html($subtag->name); ?></a>
			
		<?php }  ?>
		</div>
		
		<?php }else{ 
			
		$site_zksycmscd_text = _cao('site_zksycmscd_text');
		if (is_array($site_zksycmscd_text)  && _cao('home_zksycmscd_text') ) : ?>
		<div class="choosetype">
		<a href="<?php echo $site_zksycmscd_text['zksycmscd1_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd1_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd2_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd2_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd3_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd3_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd4_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd4_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd5_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd5_text']; ?></a>
		<a href="<?php echo $site_zksycmscd_text['zksycmscd6_link']; ?>" target="_blank"><?php echo $site_zksycmscd_text['zksycmscd6_text']; ?></a> 
		</div>
		<?php endif;
		
		} ?>
		
		
		<!--云创源码网CMS菜单-->	  	
	  	<?php _the_cao_ads('ad_list_header', 'list-header');?>
		<div class="row cat-posts-wrapper">
		    <?php while ( $data->have_posts() ) : $data->the_post();
		      get_template_part( 'parts/template-parts/content',$cms['latest_layout'] );
		    endwhile; ?>
		</div>
		<?php _the_cao_ads('ad_list_footer', 'list-footer');?>
	  </div>
	</div>

	<?php 
	wp_reset_postdata();
}
?>