<!--云创源码www.loowp.com-->
<?php
/*
Template Name: 自助申请友链
* 提示：友情链接，需在后台审核
*/
?>
<?php
if( isset($_POST['blink_form']) && $_POST['blink_form'] == 'send'){
global $wpdb;

// 表单变量初始化
$link_name = isset( $_POST['blink_name'] ) ? trim(htmlspecialchars($_POST['blink_name'], ENT_QUOTES)) : '';
$link_url = isset( $_POST['blink_url'] ) ? trim(htmlspecialchars($_POST['blink_url'], ENT_QUOTES)) : '';
$link_description = isset( $_POST['blink_lianxi'] ) ? trim(htmlspecialchars($_POST['blink_lianxi'], ENT_QUOTES)) : ''; // 联系方式
$link_target = "_blank";
$link_visible = "N"; // 表示链接默认不可见

// 表单项数据验证
if ( empty($link_name) || mb_strlen($link_name) > 20 ){
wp_die('连接名称必须填写，且长度不得超过30字');
}

//if ( empty($link_url) || strlen($link_url) > 60 || !preg_match("/^(https?:\/\/)?(((www\.)?[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)?\.([a-zA-Z]+))|(([0-1]?[0-9]?[0-9]|2[0-5][0-5])\.([0-1]?[0-9]?[0-9]|2[0-5][0-5])\.([0-1]?[0-9]?[0-9]|2[0-5][0-5])\.([0-1]?[0-9]?[0-9]|2[0-5][0-5]))(\:\d{0,4})?)(\/[\w- .\/?%&=]*)?$/i", $link_url)) { //验证url
//wp_die('链接地址必须填写');
//}

$sql_link = $wpdb->insert(
$wpdb->links,
array(
'link_name' => '【待审核】--- '.$link_name,
'link_url' => $link_url,
'link_target' => $link_target,
'link_description' => $link_description,
'link_visible' => $link_visible
)
);

$result = $wpdb->get_results($sql_link);

wp_die('亲，友情链接提交成功，【等待站长审核中】！<p><a href="/">点此返回</a>', '提交成功');

}

get_header();
?>

<div id="main">
<div class="container">
<div class="card-header bg-transparent">
<h3 class="mb-0" style="text-align: center;">申请友情链接</h3>
</div>
<div class="srcdict-yqlj">
<div class="col-lg-6 col-12">
<!--表单开始-->
<form method="post" class="mt20" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">

<div class="form-group">
<label for="blink_name"><font color="red">*</font> 链接名称:</label>
<input type="text" size="40" value="" class="form-control" id="blink_name" placeholder="请输入链接名称" name="blink_name" />
</div>

<div class="form-group">
<label for="blink_url"><font color="red">*</font> 链接地址:</label>
<input type="text" size="40" value="" class="form-control" id="blink_url" placeholder="请输入链接地址" name="blink_url" />
</div>

<div class="form-group">
<label for="blink_lianxi">联系QQ:</label>
<input type="text" size="40" value="" class="form-control" id="blink_lianxi" placeholder="请输入联系QQ" name="blink_lianxi" />
</div>

<div>
<input type="hidden" value="send" name="blink_form" />
<button type="submit" class="btn btn-primary">提交申请</button>
<button type="reset" class="btn btn-default">重填</button>
（提示：带有<font color="red">*</font>，表示必填项~）
</div>
</form>
<!--表单结束-->
</div>

<div class="col-lg-6 col-12">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article class="col-md-10 mt20 col-md-offset-2 clearfix" style="margin-top: 20px;margin-bottom: 15px;padding: 1rem 1.5rem;">
<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>

<?php
$site_zlink_text = _cao('site_zlink_text');
if (is_array($site_zlink_text)  && _cao('home_zlink_text') ) : ?>
<p class="mt20"><?php echo $site_zlink_text['zlink_1_text']; ?></p>

<p class="mt20"><strong><?php echo $site_zlink_text['zlink_1_down']; ?></strong></p>

<p>&#x2714; <?php echo $site_zlink_text['zlink_2_down']; ?></p>

<p>&#x2714; <?php echo $site_zlink_text['zlink_3_down']; ?></p>

<p>&#x2714; <?php echo $site_zlink_text['zlink_4_down']; ?></p>

<p>&#x2714; <?php echo $site_zlink_text['zlink_5_down']; ?></p>

<p class="mt20"><strong><?php echo $site_zlink_text['zlink_6_down']; ?></strong></p>

<p>名称：<?php echo $site_zlink_text['zlink_7_down']; ?></p>

<p>网址：<?php echo $site_zlink_text['zlink_8_down']; ?></p>

<p>描述：<?php echo $site_zlink_text['zlink_9_down']; ?></p>
<?php endif; ?>
</div>

</article>
<?php endwhile; else: ?>
<?php endif; ?>
</div>
</div>
</div>
<?php get_footer(); ?>