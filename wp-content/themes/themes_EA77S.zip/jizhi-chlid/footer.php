</div><!-- end sitecoent --> 

<?php 
global $current_user;
$uid = (is_user_logged_in()) ? $current_user->ID : 0 ;
$CaoUser = new CaoUser($uid);

if(_cao( 'home_nocopy', true )&&!is_admin()){ 

?>

<script type="text/Javascript">
    document.oncontextmenu=function(e){return false;}; document.onselectstart=function(e){return false;};
</script>
<style>
    body {-moz-user-select: none;}
</style>
<SCRIPT LANGUAGE=javascript>
    if (top.location != self.location) top.location = self.location;
</SCRIPT>
<noscript>
    <iframe src=*.Html></iframe>
</noscript>
<?php } ?>

	<?php
	$mode_banner = _cao('mode_banner');
	if (is_array($mode_banner) && isset($mode_banner['bgimg']) && _cao('is_footer_banner') ) : ?>

	<div class="module parallax">
		<img class="jarallax-img lazyload" data-srcset="<?php echo $mode_banner['bgimg']; ?>" data-sizes="auto" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="">
		<div class="container">
		<div class="zhankr">
		<ul class="data-items">
        <li><i class="fa fa-group"></i><strong data-count="97596" class="active"><?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?></strong><span>会员总数(位)</span>
        </li>
        <li><i class="fa fa-chrome"></i><strong data-count="34774" class="active"><?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?></strong><span>资源总数(个)</span>
        </li>
        <li><i class="fa fa-diamond"></i><strong data-count="841940" class="active"><?php echo get_week_post_count(); ?></strong><span>本周发布(个)</span>
        </li>
        <li><i class="fa fa-cloud-upload"></i><strong data-count="2377" class="active"><?php echo WeeklyUpdate();?> </strong><span>今日发布(个)</span>
        </li>
        <li><i class="fa fa-desktop"></i><strong data-count="7082" class="active"><?php echo floor((time()-strtotime("2020-04-01"))/86400); ?></strong><span>稳定运行(天)</span>
        </li>
		</ul>
		</div>
			<h4 class="entry-title">
				<?php echo wp_kses( $mode_banner['text'], array(
					'br' => array(),
				) ); ?>
			</h4>
			<?php if ( $mode_banner['primary_text'] != '' ) : ?>
				<a<?php echo _target_blank(); ?> class="button" href="<?php echo esc_url( $mode_banner['primary_link'] ); ?>"><?php echo esc_html( $mode_banner['primary_text'] ); ?></a>
			<?php endif; ?>
			<?php if ( $mode_banner['secondary_text'] != '' ) : ?>
				<a<?php echo _target_blank(); ?> class="button transparent" href="<?php echo esc_url( $mode_banner['secondary_link'] ); ?>"><?php echo esc_html( $mode_banner['secondary_text'] ); ?></a>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>

	<footer class="site-footer">
		<div class="container">
			
			<?php if (_cao( 'is_diy_footer','true' ) ){
				get_template_part( 'parts/diy-footer' );
			}?>
			<?php if ( _cao( 'cao_copyright_text', '' ) != '' ) : ?>
			  <div class="site-info">
			    <?php echo _cao( 'cao_copyright_text', '' ); ?>
			    <?php if(_cao('cao_ipc_info')) : ?>
			    <a href="https://beian.miit.gov.cn" target="_blank" class="text" rel="nofollow"> <?php echo _cao('cao_ipc_info')?><br></a>
			    <?php endif; ?>
			    <?php
			    $site_dibu_text = _cao('site_dibu_text');
			    if (is_array($site_dibu_text)  && _cao('home_dibu_text') ) : ?>
			    	<a href="<?php echo $site_dibu_text['dibu_1_link']; ?>" target="_blank" rel="nofollow"><i class="fa fa-sitemap" aria-hidden="true"></i> <?php echo $site_dibu_text['dibu_1_text']; ?></a>  | <a href="<?php echo $site_dibu_text['dibu_2_link']; ?>" target="_blank" rel="nofollow"><i class="fa fa-sitemap" aria-hidden="true"></i> <?php echo $site_dibu_text['dibu_2_text']; ?></a><br>
			    <?php endif; ?>
			    <?php
			    $site_dibuimg_text = _cao('site_dibuimg_text');
			    if (is_array($site_dibuimg_text)  && _cao('home_dibuimg_text') ) : ?>
				<a href="<?php echo $site_dibuimg_text['dibu_img1_link']; ?>" class="aq" target="_blank" rel="nofollow"><img src="<?php echo $site_dibuimg_text['dibu_img1_text']; ?>"/></a>&nbsp;
				<a href="<?php echo $site_dibuimg_text['dibu_img2_link']; ?>" class="aq" target="_blank" rel="nofollow"><img src="<?php echo $site_dibuimg_text['dibu_img2_text']; ?>"/></a>	&nbsp;			
				<a href="<?php echo $site_dibuimg_text['dibu_img3_link']; ?>" class="aq" target="_blank" rel="nofollow"><img src="<?php echo $site_dibuimg_text['dibu_img3_text']; ?>"/></a>&nbsp;
			  </div>
			  <?php endif; ?>
			<?php endif; ?>
		</div>
	</footer>
	
<!--右侧跟随导航开始-->
<?php
$site_cbl_text = _cao('site_cbl_text');
if (is_array($site_cbl_text)  && _cao('home_cbl_text') ) : ?>
<div class="float-box">
  	<ul class="float-ul float-radius float-text dbsvip" style="box-shadow: 0px 0px 8px 8px rgba(255, 12, 0, 0.42);">
		<li>
			<a class="qq float-border float-text dbsvipa" href="<?php echo $site_cbl_text['cbl_1_link']; ?>" rel="external nofollow noopener noreferrer" target="_Blank" >
				<i class="fa fa-diamond" style="font-size: 18px;"></i><br><?php echo $site_cbl_text['cbl_1_text']; ?>				
				<div class="float-alert-box float-radius float-qq-box" style="display:none;">
					<h6 style="color: #ff402f;">升级</h6>
					<p><?php echo $site_cbl_text['cbl_11_text']; ?><br><?php echo $site_cbl_text['cbl_12_text']; ?></p>
					<div class="float-qq-btn float-radius dbsvipd" onclick="window.open('<?php echo $site_cbl_text['cbl_1_link']; ?>','_blank')">立即升级</div>
				</div>
			</a>
		</li>
	</ul>
	
  	<ul class="float-ul float-radius float-text">
      <li>
      <?php if (_cao('is_qiandao','1')) : ?>
            <a class="click-qiandao zzhuti_qd_1" href="javascript:void(0);" etap="to_top" title="打卡签到">
                <?php if (_cao_user_is_qiandao()) {
                    echo '已签';
                }else{
                    echo '签到 ';
                }
                ?>
            </a>
            <?php endif; ?>
		</li>
	</ul>
  
	<ul class="float-ul float-radius float-text">
		<li>
			<a class="qq float-border float-text" href="https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo _cao('site_kefu_qq');?>&amp;site=qq&amp;menu=yes" target="_Blank" rel="external nofollow noopener noreferrer">
				<i class="fa fa-qq"></i><br><?php echo $site_cbl_text['cbl_2_text']; ?>				
				<div class="float-alert-box float-radius float-qq-box" style="display:none;">
					<h6>工作时间</h6>
					<p><?php echo $site_cbl_text['cbl_21_text']; ?><br><?php echo $site_cbl_text['cbl_22_text']; ?></p>
					<div class="float-qq-btn float-radius" onclick="window.open('https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo _cao('site_kefu_qq');?>&amp;site=qq&amp;menu=yes','_blank')">点击咨询客服</div>
				</div>
			</a>
		</li>
	</ul>
	<ul class="float-ul float-radius float-text">
		<li>
			<a class="float-border float-text" href="javascript:void(0);" etap="to_full" title="点击全屏" rel="external nofollow noopener noreferrer">
				<i class="fa fa-arrows-alt"></i><br>全屏
			</a>
		</li>
	</ul>
  	<ul class="float-ul float-radius float-text">
		<li>
			<a class="float-border float-text" href="javascript:void(0);" etap="to_top" title="返回顶部">
				<i class="fa fa-angle-double-up"></i><br>
			</a>
		</li>
	</ul>

</div>

<script>
$(".qq").hover(function () {
	$(this).children(".float-qq-box").show()
},function() {
	$(this).children(".float-qq-box").hide()
});
$(".weixin").hover(function () {
	$(this).children(".float-weixin-box").show()
},function() {
	$(this).children(".float-weixin-box").hide()
});
</script>
<?php endif; ?>
<!--右侧跟随导航结束-->	

<div class="dimmer"></div>

<?php if (!is_user_logged_in() && is_site_shop_open()) : ?>
    <?php get_template_part( 'parts/popup-signup' ); ?>
<?php endif; ?>

<?php get_template_part( 'parts/off-canvas' ); ?>

<?php if (_cao('is_console_footer','true')) : ?>
<script>
    console.log("\n %c <?php echo _the_theme_name().' V'._the_theme_version();?> %c https://www.loowp.com \n\n", "color: #fadfa3; background: #030307; padding:5px 0;", "background: #fadfa3; padding:5px 0;");
    console.log("SQL 请求数：<?php echo get_num_queries();?>");
    console.log("页面生成耗时： <?php echo timer_stop(0,5);?>");
</script>
<!--美化部位-->
<style type="text/css">
.icon {
width: 1em; height: 1em;
vertical-align: -0.15em;
fill: currentColor;
overflow: hidden;
}
</style>
<script type="text/javascript">

jQuery(document).ready(function($){

$('.ct h3 span').click(function(){

$(this).addClass("selected").siblings().removeClass();

  $('.ct > ul').eq($(this).index()).addClass('show');
 $('.ct > ul').eq($(this).index()).siblings().removeClass('show');
});
 $("pre > code").addClass("language-php");
});

	jQuery(".header-dropdown").hover(function() {
		jQuery(this).addClass('active');
	}, function() {
		jQuery(this).removeClass('active');
	});


</script>
<script>
(function($) {
    $.fn.FontScroll = function(options) {
        var d = { time: 3000, s: 'fontColor', num: 1 }
        var o = $.extend(d, options);


        this.children('ul').addClass('line');
        var _con = $('.line').eq(0);
        var _conH = _con.height(); 
        var _conChildH = _con.children().eq(0).height(); 
        var _temp = _conChildH; 
        var _time = d.time; 
        var _s = d.s; 


        _con.clone().insertAfter(_con); 

        
        var num = d.num;
        var _p = this.find('li');
        var allNum = _p.length;

        _p.eq(num).addClass(_s);


        var timeID = setInterval(Up, _time);
        this.hover(function() { clearInterval(timeID) }, function() { timeID = setInterval(Up, _time); });

        function Up() {
            _con.animate({ marginTop: '-' + _conChildH });
            
            _p.removeClass(_s);
            num += 1;
            _p.eq(num).addClass(_s);

            if (_conH == _conChildH) {
                _con.animate({ marginTop: '-' + _conChildH }, "normal", over);
            } else {
                _conChildH += _temp;
            }
        }

        function over() {
            _con.attr("style", 'margin-top:0');
            _conChildH = _temp;
            num = 1;
            _p.removeClass(_s);
            _p.eq(num).addClass(_s);
        }
    }
})(jQuery);


$(function() {
    $('.marquee_box').FontScroll({ time: 5000, num: 1 });
});
</script>
<!--美化部位-->

<!--活动弹屏-->
<?php
$site_zksy_text = _cao('site_zksy_text');
if (is_array($site_zksy_text)  && _cao('home_jzvip_text') ) : ?>
<div id="right_ad_20200520" class="" style="display: block;">
    <div class="kubao" style="display: block;">
        <span class="sm"></span>
    </div>
    <a class="link animated" href="/svip" data-stat="升级活动特价" target="_blank"
       style="display: none;border:none;box-shadow:none">
        <span class="ly-db-text"></span>
        <em class="close">×</em>
    </a>
</div>
<?php
wp_enqueue_script('rightad', get_stylesheet_directory_uri() . '/css/zhankr-jizhi.js');
wp_enqueue_style('rightad', get_stylesheet_directory_uri() . '/css/zhankr-jizhi.css');
?>
<?php endif; ?>
<!--活动弹屏-->

<?php endif; ?>

<?php if (_cao('web_js')) : ?>
<?php echo _cao('web_js');?>
<?php endif; ?>
<?php if (_cao('cao_disabled_f12')) : ?>
<script type="text/javascript">
((function() {
    var callbacks = [],
        timeLimit = 50,
        open = false;
    setInterval(loop, 1);
    return {
        addListener: function(fn) {
            callbacks.push(fn);
        },
        cancleListenr: function(fn) {
            callbacks = callbacks.filter(function(v) {
                return v !== fn;
            });
        }
    }
    function loop() {
        var startTime = new Date();
        debugger;
        if (new Date() - startTime > timeLimit) {
            if (!open) {
                callbacks.forEach(function(fn) {
                    fn.call(null);
                });
            }
            open = true;
            window.stop();
            alert('不要扒我了');
            window.location.reload();
        } else {
            open = false;
        }
    }
})()).addListener(function() {
    window.location.reload();
});
</script>
<?php endif; ?>

<?php wp_footer(); ?>
<div class="waveHorizontals mobile-hide">
  <div id="waveHorizontal1" class="waveHorizontal"></div>
  <div id="waveHorizontal2" class="waveHorizontal"></div>
  <div id="waveHorizontal3" class="waveHorizontal"></div>
</div>
<!--手机导航-->
<?php
$site_zksy_text = _cao('site_zksy_text');
//if (is_array($site_zksy_text)  && _cao('home_zksjcd_text') ) : 
if (true) : 
?>
<div id="foot-memu" class="aini_foot_nav">
  <ul>
    <li> <a href="/" class="foothover"> <i class="nohover fa fa-home"></i>
      <p>首页</p>
      </a> </li>
    <li> <a class="click-qiandao" href="javascript:void(0);" etap="to_top" title="打卡签到"> <i class="nohover fa fa-calendar-check-o"></i>
      <p>签到</p>
      </a> </li>
    <li class="aini_zjbtn"> <a href="/svip" rel="nofollow" data-block="666" data-position="8" target="_blank"> <em class="bg_f b_ok"></em> <span class="bg_f"> <i class="foot_btn f_f iconjiahao fa fa-diamond"></i> </span> </a> </li>
    <li> <a class="rollbar-item tap-dark" href="javascript:void(0);" etap="tap-dark" title="夜间模式"> <i class="nohover fa fa-lightbulb-o"></i>
      <p>切换</p>
      </a> </li>
    <li> <a target="_blank"  title="QQ咨询" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _cao('site_kefu_qq');?>&site=qq&menu=yes" rel="external nofollow noopener noreferrer"> <i class="nohover fa fa-comments-o"></i>
      <p>客服</p>
      </a> </li>
  </ul>
</div>
<?php endif; ?>
<!--手机导航-->
<?php if(_cao('is_bottom_notify')){?><div class="sitetips"><i class="fa fa-horn"></i> <?php echo _cao('site_notify_fixed');?><a href="javascript:;" class="close"><i class="fa fa-close"></i></a></div><?php }?>	
<!--常见问题-->
<script>
  var ndt = $("#help dt");
  var ndd = $("#help dd");
  ndd.eq(0).show();
  ndt.click(function () {
    ndd.hide();
    $(this).next().show();
  });
</script>
<!--常见问题-->

</body>
</html>