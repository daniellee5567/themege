<?php


require_once get_template_directory() . '/inc/shortcodes/shortcodespanel.php';
require_once get_template_directory() . '/inc/shortcodes/shortcodes.php';


add_filter( 'wp_sitemaps_enabled', '__return_false' );
add_filter('xmlrpc_enabled', '__return_false');

function ludou_get_cat_postcount($id) {
    // 获取当前分类信息
    $cat = get_category($id);
    // 当前分类文章数
    $count = (int) $cat->count;
    // 获取当前分类所有子孙分类
    $tax_terms = get_terms('category', array('child_of' => $id));
    foreach ($tax_terms as $tax_term) {
    // 子孙分类文章数累加
        $count +=$tax_term->count;
    }
    return $count;
}

function add_stylesheet_to_head() {
    //echo '<link rel="stylesheet" id="icon-css" href="//at.alicdn.com/t/font_1417942_3rumht8vvmh.css" type="text/css" media="all">';
}
 
add_action( 'wp_head', 'add_stylesheet_to_head' );

//默认搜索伪静态
function wp_search_url_rewrite() {
    if ( is_search() && ! empty( $_GET['s'] ) ) {
        wp_redirect( home_url( "/search/" ) . urlencode( get_query_var( 's' ) ) . "/");
        exit();
    }
}
add_action( 'template_redirect', 'wp_search_url_rewrite' );

add_filter('posts_search', 'filter_search_by_title', 1000, 2);
function filter_search_by_title($search, $query) {
    if (!is_admin() || !current_user_can('manage_options')) {
        return $search;
    }
 
    // 确保我们在管理后台，并且当前用户有管理权限
    if (isset($query->query['search_columns'])) {
        $search_columns = $query->query['search_columns'];
        unset($search_columns['title']);
        $query->query['search_columns'] = array('title' => '%' . $query->query['s'] . '%');
    }
 
    return $search;
}

/**
 * 子主题函数
 * RiPro是一个优秀的主题，首页拖拽布局，高级筛选，自带会员生态系统，超全支付接口，你喜欢的样子我都有！
 * 本子主题基于Ripro主题
 * 正版唯一购买地址，无需授权下载使用：https://www.loowp.com/
 * 作者唯一QQ：80027422 （云创源码）
 * 承蒙您对本主题的喜爱，我们愿向小三一样，做大哥的女人，做大哥网站中最想日的一个。
 * 能理解使用盗版的人，但是不能接受传播盗版，本身主题没几个钱，主题自有支付体系和会员体系，盗版风险太高，鬼知道那些人乱动什么代码，无利不起早。
 * 开发者不易，感谢支持，更好的更用心的等你来调教
 */
//加载style.css 子主题样式
function ripro_chlid_style() {
    if (!is_admin()) {
    	//挂在父主题优先最前
        wp_register_style('ripro_chlid_style', get_stylesheet_directory_uri() . '/diy.css',  array('app'), '', 'all');
        wp_enqueue_style('ripro_chlid_style');
    }
}
add_action('init', 'ripro_chlid_style');



//关闭rss feed功能
function disable_all_feeds() {
	wp_die(__('<h1>本博客不提供Feed，请访问网站<a href="'.get_bloginfo('url').'">首页</a>！</h1>'));
}
add_action('do_feed', 'disable_all_feeds', 1);
add_action('do_feed_rdf', 'disable_all_feeds', 1);
add_action('do_feed_rss', 'disable_all_feeds', 1);
add_action('do_feed_rss2', 'disable_all_feeds', 1);
add_action('do_feed_atom', 'disable_all_feeds', 1);

remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'wp_head', 'feed_links', 2 );



//图片添加alt属性
function _image_alt($content) {
    global $post;
    $title = $post->post_title;
    $rules = array(
        '/<img(.*?) alt="(.*?)"/i' => '<img$1',
        '/<img(.*?) src="(.*?)"/i' => '<img$1 src="$2" alt="'.$title.'" title="'.$title.'-'.get_option('blogname').'"',
    );
    foreach($rules as $p => $r){
        $content = preg_replace($p,$r,$content);
    }
    return $content;
}
add_filter( 'the_content', '_image_alt');

// 给文章和页面的编辑页添加选项
function ludouseo_add_custom_box() {  
 add_meta_box('ludou_se_only', '搜索引擎专属', 'ludou_se_only', 'post', 'side', 'low');
 add_meta_box('ludou_se_only', '搜索引擎专属', 'ludou_se_only', 'page', 'side', 'low');
 add_meta_box('ludou_se_only', '搜索引擎专属', 'ludou_se_only', 'product', 'side', 'low');
}
add_action('add_meta_boxes', 'ludouseo_add_custom_box');
 
function ludou_se_only() {
 global $post;
  
 //添加验证字段
 wp_nonce_field('ludou_se_only', 'ludou_se_only_nonce');
  
 $meta_value = get_post_meta($post->ID, 'ludou_se_only', true);
 if($meta_value)
  echo '<input name="ludou-se-only" type="checkbox" checked="checked" value="1" /> 只允许搜索引擎查看';
 else
  echo '<input name="ludou-se-only" type="checkbox" value="1" /> 只允许搜索引擎查看';
}
 
// 保存选项设置
function ludouseo_save_postdata($post_id) {
 // 验证
 if ( !isset( $_POST['ludou_se_only_nonce']))
  return $post_id;
 $nonce = $_POST['ludou_se_only_nonce'];
  
 // 验证字段是否合法
 if (!wp_verify_nonce( $nonce, 'ludou_se_only'))
  return $post_id;
   
 // 判断是否自动保存
 if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
   return $post_id;
    
 // 验证用户权限
 if ('page' == $_POST['post_type']) {
  if ( !current_user_can('edit_page', $post_id))
   return $post_id;
 } else {
  if (!current_user_can('edit_post', $post_id))
   return $post_id;
 }
 
 $type=sanitize_text_field($_POST['tt_member_see_type']);
 if(!empty($type))
  update_post_meta($post_id, 'tt_member_see_type', $type);
 
 
 // 更新设置
 if(!empty($_POST['ludou-se-only']))
  update_post_meta($post_id, 'ludou_se_only', '1');
 else
  delete_post_meta($post_id, 'ludou_se_only');
}
add_action('save_post', 'ludouseo_save_postdata');
 
function do_ludou_se_only() {
 // 本功能只对文章和页面有效
 if(is_singular()) {
  global $post;
  $is_robots = 0;
  $ludou_se_only = get_post_meta($post->ID, 'ludou_se_only', true);
   
  if(!empty($ludou_se_only)) {
   // 下面是搜索引擎Agent判断关键字数组
   // 有点简单，自己优化一下吧
   $bots = array(
      'spider',
      'bot',
      'crawl',
      'Slurp',
      'yahoo-blogs',
      'Yandex',
      'Yeti',
      'blogsearch',
      'ia_archive',
      'Google'
      );
   
   $useragent = $_SERVER['HTTP_USER_AGENT'];
   
   if(!empty($useragent)) {
    foreach ($bots as $lookfor) {
     if (stristr($useragent, $lookfor) !== false) {
      $is_robots = 1;
      break;
     }
    }
   }
    
   // 如果不是搜索引擎，就显示错误信息
   // 已登录的用户不受影响
   if(!$is_robots) {
   	$txt='抱歉，指定的主题不存在或已被删除或正在被审核!';
   	cao_wp_die('你迷路了吗？',$txt);
    //wp_redirect('https://www.loowp.com/', 301);
    //exit;
   }
  }
 }
}
add_action('wp', 'do_ludou_se_only');

//加载云创源码高级功能
/**
 * 后台设置
 */
require_once get_template_directory() . '/inc/codestar-framework/codestar-framework.php';

require_once plugin_dir_path( __FILE__ ) .'zhankr/options.theme.php';

// 每周更新的文章数量
function get_week_post_count(){
$date_query = array(
array(
'after'=>'1 week ago'
)
);$args = array(
'post_type' => 'post',
'post_status'=>'publish',
'date_query' => $date_query,
'no_found_rows' => true,
'suppress_filters' => true,
'fields'=>'ids',
'posts_per_page'=>-1
);
$query = new WP_Query( $args );
echo $query->post_count+30;
}
// 每日更新的文章数量
function WeeklyUpdate() {
$today = getdate();
$query = new WP_Query( 'year=' . $today["year"] . '&monthnum=' . $today["mon"] . '&day=' . $today["mday"]);
$postsNumber = $query->found_posts+10;
echo $postsNumber;
}

//文章数排序
/*
Plugin Name: Sort Users by Post Count
Description: Add a column to the Users page in the admin to sort users by post counts.https://github.com/ksemel/sort-users-by-post-count
Version: 1.0
Author: Katherine Semel
*/
if ( ! class_exists('Sort_Users_By_Post_Count') ) {
    class Sort_Users_By_Post_Count {
        function __construct() {
            // Make user table sortable by post count
            add_filter( 'manage_users_sortable_columns', array( $this, 'add_custom_user_sorts' ) );
        }
        /* Add sorting by post count to user page */
        function add_custom_user_sorts( $columns ) {
            $columns['posts'] = 'post_count';
            return $columns;
        }
    }
    $Sort_Users_By_Post_Count = new Sort_Users_By_Post_Count();
}

//用户注册时间排序
add_filter('manage_users_columns', function($column_headers){
	$column_headers['registered'] = '注册时间';
	return $column_headers;
});

add_filter('manage_users_custom_column', function($value, $column_name, $user_id){
	if($column_name=='registered'){
		$user = get_userdata($user_id);
		return get_date_from_gmt($user->user_registered);
	}else{
		return $value;
	}
},11,3);


add_filter('manage_users_sortable_columns', function($sortable_columns){
	$sortable_columns['reg_time'] = 'reg_time';
	return $sortable_columns;
});

add_action('pre_user_query', function($query){
	if(!isset($_REQUEST['orderby']) || $_REQUEST['orderby']=='reg_time' ){
		if( !in_array($_REQUEST['order'],array('asc','desc')) ){
			$_REQUEST['order'] = 'desc';
		}
		$query->query_orderby = "ORDER BY user_registered ".$_REQUEST['order']."";
	}
});


// WordPress 自动为文章添加已使用过的标签
function array2object($array) {
	// 数组转对象
	if (is_array($array)) {
		$obj = new StdClass();
		foreach ($array as $key => $val) {
			$obj->$key = $val;
		}
	} else {
		$obj = $array;
	}
	return $obj;
}
function object2array($object) {
	// 对象转数组
	if (is_object($object)) {
		foreach ($object as $key => $value) {
			$array[$key] = $value;
		}
	} else {
		$array = $object;
	}
	return $array;
}
add_action('save_post', 'auto_add_tags');
function auto_add_tags() {
	$tags = get_tags( array('hide_empty' => false) );
	$post_id = get_the_ID();
	$post_content = get_post($post_id)->post_content;
	$post_tags=wp_get_post_tags($post_id);
	if ($tags) {
		$i = count($post_tags);
		$arrs = object2array($tags);
		shuffle($arrs);
		$tags = array2object($arrs);
		// 打乱顺序
		foreach ( $tags as $tag ) {
			// 如果文章内容出现了已使用过的标签，自动添加这些标签
			if ( strpos($post_content, $tag->name) !== false) {
				if ($i > 4) {
					// 控制输出数量
					break;
				}
				wp_set_post_tags( $post_id, $tag->name, true );
				$i++;
			}
		}
	}
}
/* 自动为文章内的标签添加内链 */
$match_num_from = 2;
//一篇文章中同一个标签少于几次不自动链接
$match_num_to = 1;
//一篇文章中同一个标签最多自动链接几次
function tag_sort($a, $b) {
	if ( $a->name == $b->name ) return 0;
	return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
}
function tag_link($content) {
	global $match_num_from,$match_num_to;
	$posttags = get_the_tags();
	if ($posttags) {
		usort($posttags, "tag_sort");
		foreach($posttags as $tag) {
			$link = get_tag_link($tag->term_id);
			$keyword = $tag->name;
			$cleankeyword = stripslashes($keyword);
			$url = "<a href=\"$link\" title=\"".str_replace('%s',addcslashes($cleankeyword, '$'),__('【查看更多[%s]标签的文章】'))."\"";
			$url .= ' target="_blank"';
			$url .= ">".addcslashes($cleankeyword, '$')."</a>";
			$limit = rand($match_num_to,$match_num_from);
			$content = preg_replace( '|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
			$content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);
			$cleankeyword = preg_quote($cleankeyword,'\'');
			$regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
			$content = preg_replace($regEx,$url,$content,$limit);
			$content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);
		}
	}
	return $content;
}
add_filter('the_content','tag_link',1);

//启用友情链接

add_filter('pre_option_link_manager_enabled','__return_true');

//导航栏目统计
function wt_get_category_count($cat_ID) {
	$category = get_category($cat_ID);
	return $category->count;
}
function zhankr_nav_items_num( $items,$args ) {
	if(isset($args->theme_location) && $args->theme_location == 'menu-1') {
		foreach ( $items as $key=>$item ) {
			if($item->object == 'category') {
				//$cat = get_category_by_slug($slug);
				$catID = isset($item->object_id) ? $item->object_id : false;
				if($catID && $item->post_parent!=0) {
					$a=wt_get_category_count($catID);
					$items[$key]->title.= '<span class="zhankr-num">'.$a.'</span>';
				}
			}
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'zhankr_nav_items_num',10,2 );

//云创源码添加文本编辑自定义快捷标签按钮
 add_action('after_wp_tiny_mce', 'bolo_after_wp_tiny_mce');
 function bolo_after_wp_tiny_mce($mce_settings) {
 ?>
 <script type="text/javascript"> 
 QTags.addButton( 'z_mhz', '迷幻紫', '<div id="zk_mhz">迷幻紫</div>\n', "" );
 QTags.addButton( 'z_xgh', '西瓜红', '<div id="zk_xgh">西瓜红</div>\n', "" );
 QTags.addButton( 'z_tkzj', '天空之境', '<div id="zk_tkzj">天空之境</div>\n', "" );
 QTags.addButton( 'z_xyz', '小宇宙', '<div id="zk_xyz">小宇宙</div>\n', "" );
 QTags.addButton( 'z_gll', '橄榄绿', '<div id="zk_gll">橄榄绿</div>\n', "" );
 QTags.addButton( 'z_xty', '小太阳', '<div id="zk_xty">小太阳</div>\n', "" );
 QTags.addButton( 'z_yyz', '优雅紫', '<div id="zk_yyz">优雅紫</div>\n', "" );
 QTags.addButton( 'z_szh', '深邃黑', '<div id="zk_szh">深邃黑</div>\n', "" );
 QTags.addButton( 'z_wbk', '无边框', '<div id="zk_wbk">无边框</div>\n', "" ); 
 function bolo_QTnextpage_arg1() {
 }
 </script>
 <?php
 }
//优快讯功能
add_action('init', 'my_shuoshuo');
function my_shuoshuo()
{ $labels = array( 'name' => '优快讯',
'singular_name' => '优快讯',
'add_new' => '发表快讯',
'add_new_item' => '发表快讯',
'edit_item' => '编辑快讯',
'new_item' => '新快讯',
'view_item' => '查看快讯',
'search_items' => '搜索快讯',
'not_found' => '暂无快讯',
'not_found_in_trash' => '没有已遗弃的快讯',
'parent_item_colon' => '', 'menu_name' => '优快讯' );
$args = array( 'labels' => $labels,
'public' => true,
'publicly_queryable' => true,
'show_ui' => true,
'show_in_menu' => true,
'exclude_from_search' =>true,
'query_var' => true,
'rewrite' => true,
'capability_type' => 'post',
'has_archive' => true, 'hierarchical' => false,
'menu_position' => null, 'supports' => array('editor','author','title','comments') );
register_post_type('youkuaixun',$args);
}