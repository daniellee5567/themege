<?php if (!defined('ABSPATH')) {die;} // Cannot access directly.


$prefix_post_opts_style = 'style-postmeta-box';
CSF::createMetabox($prefix_post_opts_style, array(
    'title'     => '<span class="badge badge-radius badge-primary">RIPRO</span> 文章内容布局',
    'post_type' => 'post',
    'data_type' => 'unserialize',
    'context' => 'side',
));
CSF::createSection($prefix_post_opts_style, array(
    'fields' => array(

        array(
            'id'      => 'post_style',
            'type'    => 'radio',
            'title'   => '',
            'inline'  => true,
            'options' => array(
                'sidebar'    => '内容+侧边栏',
                'no_sidebar' => '全宽',
            ),
            'default' => 'sidebar',
        ),

        // array(
        //     'id'      => 'post_shop_style',
        //     'type'    => 'radio',
        //     'title'   => '下载信息显示位置',
        //     'inline'  => true,
        //     'options' => array(
        //         'sidebar'    => '侧边栏',
        //         'top'    => '顶部',
        //         'bottom' => '底部',
        //     ),
        //     'default' => 'sidebar',
        // ),


    ),
));


/*if (!_cao('close_site_shop','0')) {*/
if(true){
    $prefix_post_opts = '_cao_post_options';
    CSF::createMetabox($prefix_post_opts, array(
        'title'     => '<span class="badge badge-radius badge-primary">RIPRO</span> 付费资源信息设置',
        'post_type' => 'post',
        'data_type' => 'unserialize',
        'priority'  => 'high',
    ));
    CSF::createSection($prefix_post_opts, array(
            
        'fields' => array(
            array(
                'id'      => 'cao_download_url',
                'type'    => 'text',
                'title'   => '外部下载地址',
                'default' => '',
                'label'    => '填写5icrx的镜像页面',
                'attributes' => array(
                    'style'    => 'width: 400px;'
                ),
            ),
            array(
                'id'      => 'baidu_url',
                'type'    => 'text',
                'title'   => '百度网盘下载地址',
                'default' => '',
                'label'    => '填写百度网盘链接',
                'attributes' => array(
                    'style'    => 'width: 400px;'
                ),
            ),
            array(
                'id'      => 'ctpan_url',
                'type'    => 'text',
                'title'   => '诚通网盘下载地址',
                'default' => '',
                'label'    => '填写诚通网盘链接',
                'attributes' => array(
                    'style'    => 'width: 400px;'
                ),
            ),
            array(
                'id'      => 'lanzhou_url',
                'type'    => 'text',
                'title'   => '蓝奏云盘下载地址',
                'default' => '',
                'label'    => '填写蓝奏云盘链接',
                'attributes' => array(
                    'style'    => 'width: 400px;'
                ),
            ),
            array(
                'id'      => 'local_url',
                'type'    => 'text',
                'title'   => '本地下载地址',
                'default' => '',
                'label'    => '填写蓝奏云盘链接',
                'attributes' => array(
                    'style'    => 'width: 400px;'
                ),
            ),
            
     //云创源码资源标签
            array(
                'id'    => 'use_vip_blacklist',
                'type'  => 'switcher',
                'title' => '限制黑名单vip用户下载',
                'default' => '0',
                'label' => '开启后将限制黑名单vip用户下载该资源',
            ),     
            array(
                'id'      => 'no_user_down',
                'type'    => 'textarea',
                'title'   => '禁止用户下载资源',
                'default' => '',
                'label'    => '以逗号分隔用户名',
            ),   
            array(
                'id'    => 'black_vip_use_backup',
                'type'  => 'switcher',
                'title' => '黑名单vip下载备用链接',
                'default' => '1',
                'label' => '开启后将黑名单vip下载备用链接',
            ), 
            
            array(
                'id'      => 'cao_vip_day',
                'type'    => 'text',
                'title'   => '黑名单VIP会员需要等待多长时间才能下载该资源，单位为天',
                'default' => '0',
                'label'    => '超过这个时长的永久VIP下载该资源会被约束,0表示不需要等待',
                'attributes' => array(
                    'style'    => 'width: 400px;'
                ),
            ),            
    //云创源码资源标签
            array(
                'id'      => 'post_style_art',
                'type'    => 'radio',
                'title'   => '资源标签',
                'inline'  => true,
                'options' => array(
                    'dujia'  => '独家',
                    'tuijian' => '推荐',
					'jingpin' => '精品',
					'zuixin' => '最新',
					'yiceshi' => '已测试',
					'hanhua'  => '汉化版'
                ),
                'desc'    => '添加资源类型标签',
                'dependency' => array('cao_status', '==', 'true'),
            ),
            
    //云创源码资源标签
            array(
                'id'      => 'cao_yuan_price',
                'type'    => 'text',
                'title'   => '资源原价：*' . _cao('site_money_ua'),
                'default' => '39',
                'label'    => '免费请填写：0',
                'attributes' => array(
                    'style'    => 'width: 100px;'
                ),
                'dependency' => array('cao_status', '==', 'true'),
            ),

            array(
                'id'      => 'cao_price',
                'type'    => 'text',
                'title'   => '资源价格：*' . _cao('site_money_ua'),
                'default' => '39',
                'label'    => '免费请填写：0',
                'attributes' => array(
                    'style'    => 'width: 100px;'
                ),
                'dependency' => array('cao_status', '==', 'true'),
            ),
            array(
                'id'      => 'cao_vip_rate',
                'type'    => 'text',
                'title'   => _cao('site_vip_name') . '会员折扣：*',
                'default' => '0',
                'label'    => '0.N 等于N折；1 等于不打折；0 等于免费',
                'attributes' => array(
                    'style'    => 'width: 100px;'
                ),
                'dependency' => array('cao_status', '==', 'true'),
            ),
            array(
                'id'    => 'cao_close_novip_pay',
                'type'  => 'checkbox',
                'title' => '普通用户禁止购买',
                'label' => '勾选后普通用户不能下单支付，只允许会员可以购买',
                'dependency' => array('cao_status', '==', 'true'),
            ),
            array(
                'id'    => 'cao_is_boosvip',
                'type'  => 'checkbox',
                'title' => '永久'._cao('site_vip_name').'会员免费',
                'default' => '0',
                'label' => '勾选后永久'._cao('site_vip_name').'会员免费，其他会员按折扣或者原价购买',
                'dependency' => array('cao_status', '==', 'true'),
            ),

            array(
                'id'    => 'cao_status',
                'type'  => 'switcher',
                'title' => '启用付费下载模块',
                'default' => '0',
                'label' => '开启后可设置付费下载专有内容',
            ),
            
            array(
                'id'         => 'cao_version',
                'type'       => 'text',
                'title'      => '资源版本号',
                'desc'       => '填入版本号',
            ),
            
            array(
                'id'         => 'cao_downurl',
                'type'       => 'upload',
                'title'      => '资源下载地址：',
                'desc'       => '可直接粘贴：支持https:,thunder:,magnet:,ed2k 开头地址，可本地上传',
                
            ),
            array(
                'id'         => 'cao_downurl_bak',
                'type'       => 'upload',
                'title'      => '备用资源地址：',
                'desc'       => '该地址方便站长记录备用资源地址，注意此地址不在前端展示',
                'default'   =>'https://pan.baidu.com/s/1Xd4eoEGhadWmDkWTX8aOLA?pwd=xxii',
                
            ),
            array(
                'id'         => 'cao_tuijian',
                'type'       => 'switcher',
                'title'      => '是否推荐',
                'desc'       => '站长推荐',
                
            ),
            array(
                'id'         => 'cao_pojie',
                'type'       => 'switcher',
                'title'      => '是否破解',
                'desc'       => '已破解',
                'default' => '0',
                
            ),
            array(
                'id'         => 'cao_diy_btn',
                'type'       => 'text',
                'title'      => '自定义按钮(NEW)',
                'subtitle'   => '为空则不显示，用 | 隔开',
                'desc'       => '格式： 下载免费版|https://www.baidu.com/',
                'dependency' => array('cao_status', '==', 'true'),
            ),
            array(
                'id'         => 'cao_pwd',
                'type'       => 'text',
                'title'      => '文件密码',
                'label'       => '不填写则无需密码',
                'attributes' => array( 'style' => 'width: 100px;' ),
                
            ),
            array(
                'id'         => 'cao_demourl',
                'type'       => 'text',
                'title'      => '演示地址',
                'label'   => '为空则不显示',
                
            ),
            array(
                'id'         => 'cao_info',
                'type'       => 'repeater',
                'title'      => '资源其他信息属性',
                'dependency' => array('cao_status', '==', 'true'),
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述内容',
                        'default' => '这里是描述内容',
                    ),
                ),
            ),
            
            array(
                'id'      => 'cao_paynum',
                'type'    => 'text',
                'title'   => '已售数量',
                'default' => mt_rand(8,30),
                'label'   => '可自定义修改数字',
                'attributes' => array(
                    'style'    => 'width: 100px;'
                ),
                // 'dependency' => array('cao_status', '==', 'true'),
            ),

        ),
    ));
}


$prefix_post_opts_video = 'video-postmeta-box';
CSF::createMetabox($prefix_post_opts_video, array(
    'title'     => '<span class="badge badge-radius badge-primary">RIPRO</span> 付费视频模块',
    'post_type' => 'post',
    'data_type' => 'unserialize',
    // 'context' => 'side',
));
CSF::createSection($prefix_post_opts_video, array(
    'fields' => array(
        array(
            'id'    => 'cao_video',
            'type'  => 'switcher',
            'title' => '启用视频模块',
            'label' => '',
        ),
        array(
            'id'    => 'cao_is_video_free',
            'type'  => 'checkbox',
            'title' => '免费视频',
            'label' => '勾选后该视频不参与任何付费逻辑，可直接展示播放',
            'default' => false,
            'dependency' => array('cao_video', '==', 'true'),
        ),
        array(
            'id'         => 'video_poster_url',
            'type'       => 'upload',
            'title'      => '视频封面图',
            'desc'       => '不设置则自动获取文章缩略图',
            'dependency' => array('cao_video', '==', 'true'),
        ),
        array(
            'id'         => 'video_url',
            'type'       => 'upload',
            'title'      => '视频播放地址',
            'desc'       => '支持mp4,m3u8(HLS格式)自动识别，支持本地上传和外链地址，不支其他平台视频解析',
            'dependency' => array('cao_video', '==', 'true'),
        ),

    ),
));


if (_cao('is_custom_post_meta_opt', '0') && _cao('custom_post_meta_opt', '0')) {
    //获取玩家配置
    $prefix_post_opts = '_custom_post_opts';
    CSF::createMetabox($prefix_post_opts, array(
        'title'     => '高级自定义文章属性',
        'post_type' => 'post',
        'data_type' => 'unserialize',
        'context'   => 'side',
    ));

    $custom_post_meta_opt = _cao('custom_post_meta_opt', '0');
    $fields_item          = array();
    foreach ($custom_post_meta_opt as $k => $v) {
        $opt = array('all' => '默认');
        foreach ($v['meta_opt'] as $value) {
            $_key       = $value['opt_ua'];
            $opt[$_key] = $value['opt_name'];
        }
        $item = array(
            'id'      => $v['meta_ua'],
            'type'    => 'select',
            'title'   => $v['meta_name'],
            'options' => $opt,
            'default' => 'option-2',
        );
        array_push($fields_item, $item);
    }
    CSF::createSection($prefix_post_opts, array(
        'fields' => $fields_item,
    ));
}



// prefix_page_opts
$prefix_page_opts = '_cao_page_options';

CSF::createMetabox($prefix_page_opts, array(
    'title'     => '页面布局',
    'post_type' => 'page',
    'data_type' => 'unserialize',
    'priority'  => 'high',
));

CSF::createSection($prefix_page_opts, array(
    'fields' => array(
        array(
            'id'      => 'post_style',
            'type'    => 'image_select',
            'title'   => '文章页布局风格',
            'options' => array(
                'sidebar'    => get_template_directory_uri() . '/assets/images/option/sidebar.jpg',
                'no_sidebar' => get_template_directory_uri() . '/assets/images/option/no-sidebar.jpg',
            ),
            'default' => 'sidebar',
        ),

    ),
));

if (!_cao('del_ripro_seo','0')) {
   $prefix_post_opts_seo = 'seo-postmeta-box';
    CSF::createMetabox($prefix_post_opts_seo, array(
        'title'     => '自定义文章SEO信息',
        'post_type' => 'post',
        'data_type' => 'unserialize',
    ));
    CSF::createSection($prefix_post_opts_seo, array(
        'fields' => array(

            array(
                'id'      => 'post_titie_s',
                'type'    => 'switcher',
                'title'   => '自定义SEO标题',
                'label'   => '不设置则自动根据WP规则显示',
                'default' => false,
            ),
            array(
                'id'         => 'post_titie',
                'type'       => 'text',
                'title'      => 'SEO标题',
                'subtitle'   => '',
                'dependency' => array('post_titie_s', '==', 'true'),
            ),
            array(
                'id'      => 'post_description_s',
                'type'    => 'switcher',
                'title'   => '自定义SEO描述',
                'label'   => '不设置则自动根据分类，标签抓取',
                'default' => false,
            ),
            array(
                'id'         => 'description',
                'type'       => 'textarea',
                'title'      => '描述内容',
                'subtitle'   => '字数控制到80-150最佳',
                'dependency' => array('post_description_s', '==', 'true'),
            ),

            array(
                'id'      => 'post_keywords_s',
                'type'    => 'switcher',
                'title'   => '自定义SEO关键词',
                'label'   => '不设置则自动根据分类，标签抓取',
                'default' => false,
            ),
            array(
                'id'         => 'keywords',
                'type'       => 'textarea',
                'title'      => '关键词',
                'subtitle'   => '关键词用英文逗号,隔开',
                'dependency' => array('post_keywords_s', '==', 'true'),
            ),

        ),
    ));
 
}
