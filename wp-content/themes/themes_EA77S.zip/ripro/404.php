<?php
get_header();
?>
<?php

function myfunc()
{
    $id=get_category_by_slug('scripts')->term_id;
    $posts = get_posts( 'numberposts=-1&category='.$id );
    //$posts = get_posts( 'numberposts=-1');
    $price = 0;
    
    foreach($posts as $post)
    {
        update_post_meta($post->ID,'use_vip_blacklist','1');
        
        /*$price = get_post_meta($post->ID,'cao_price',true);
        if(intval($price) >14){
            //update_post_meta($post->ID,'cao_price','5');
            update_post_meta($post->ID,'cao_close_novip_pay','0');
            update_post_meta($post->ID,'down_price',$price);
        }else{
            $price = get_post_meta($post->ID,'down_price',true);
            if(intval($price) < 9){
                update_post_meta($post->ID,'down_price','8');
            }else{
                update_post_meta($post->ID,'down_price','15');
            }
        }
        
        */
    } 
}



function myfunc3()
{
    $id=440;
    
    $posts = get_posts( 'numberposts=-1');
    
    foreach($posts as $post)
    {
        if(get_post_meta($post->ID,'cao_status',true))
        {
            $price1=get_post_meta($post->ID,'cao_price',true);
            $price2=get_post_meta($post->ID,'down_price',true);
            $mode = get_post_meta($post->ID,'erphp_down',true);
            if($price2 != $price1)
            {
                //file_put_contents("/www/wwwroot/www.themege.net/123.log",$post->ID);
                /*update_post_meta($post->ID,'erphp_down','4');
                delete_post_meta( $post->ID, 'start_down');
        		delete_post_meta( $post->ID, 'start_down2');
        		delete_post_meta( $post->ID, 'start_see');
        		delete_post_meta( $post->ID, 'start_see2');*/
        		
        		if($mode == '5')
        		{
        		    update_post_meta($post->ID,'erphp_down','1');
        		    update_post_meta( $post->ID, 'start_down', 'yes' );
					delete_post_meta( $post->ID, 'start_down2');
					delete_post_meta( $post->ID, 'start_see');
					delete_post_meta( $post->ID, 'start_see2');
					update_post_meta($post->ID,'member_down','3');
        		}
            }
        }
    }
    
    
    /*

    $mode = get_post_meta($id,'erphp_down',true);
     //file_put_contents("/www/wwwroot/www.themege.net/123.log",$mode);
    
    if($price2 == $price1)
    {
        update_post_meta($id,'erphp_down','4');
        delete_post_meta( $id, 'start_down');
		delete_post_meta( $id, 'start_down2');
		delete_post_meta( $id, 'start_see');
		delete_post_meta( $id, 'start_see2');
					
        //update_post_meta($id,'member_down','1');
        
    }
    
    
    */
    
}

function myfun4()
{
    $id=3839;
    //
    
    $title = get_post($id)->post_title;
    
    file_put_contents("/www/wwwroot/www.themege.net/123.log",mb_strlen($title,'utf8'));
}

function myfunc2()
{
    
    //$id=get_category_by_slug('woo-theme')->term_id;
    //$posts = get_posts( 'numberposts=-1&category='.$id );
    $posts = get_posts( 'numberposts=-1');
    
    foreach($posts as $post)
    {
        $title = get_post($post->ID)->post_title;
        

        if(mb_strlen($title,'utf8')>60)
        {
            file_put_contents("/www/wwwroot/www.themege.net/123.log",$title."\n",FILE_APPEND);
        }
    }
}

function myfunc6()
{
    $id=get_category_by_slug('wordpress-plugin')->term_id;
    $posts = get_posts( 'numberposts=-1&category='.$id );
    //$posts = get_posts( 'numberposts=-1');
    $new_price=0;

    
    foreach($posts as $post)
    {
        $price=intval(get_post_meta($post->ID,'cao_yuan_price',true));
        //update_post_meta($post->ID,'cao_yuan_price',$price);
        
       
        if($price == 39){
            $new_price=30;
        }else if($price == 49){
            $new_price=35;
        }else if($price == 59){
            $new_price=45;
        }else {
            $new_price=$price;
        }
        
        if($new_price!=0){
            update_post_meta($post->ID,'cao_price',$new_price);
        }
        
        /*if($price==199||$price==299||$price==399){
            $new_price=$price-101;
            
            update_post_meta($post->ID,'cao_price',$new_price);
        }*/
    } 
    
}

function myfunc5()
{
    //$id=get_category_by_slug('websrc')->term_id;
    //$posts = get_posts( 'numberposts=-1&category='.$id );
    $posts = get_posts( 'numberposts=-1');

    
    foreach($posts as $post)
    {
        $price=intval(get_post_meta($post->ID,'cao_yuan_price',true));
        //if($price==39){
            update_post_meta($post->ID,'cao_price',$price);
        //}
        
        /*if($price==199||$price==299||$price==399){
            $new_price=$price-101;
            
            update_post_meta($post->ID,'cao_price',$new_price);
        }*/
    } 
    
}

//myfunc5();

//CleanDownNum();
//myfunc6();


//WordPress实现自动记录死链地址
if('is_404' && strpos($_SERVER['HTTP_USER_AGENT'],'Baiduspider') !== false){
$file = @file("badlink.txt");//badlink.txt
$check = true;
if(is_array($file) && !empty($file))
	foreach($file as &$f){
		if($f == home_url($_SERVER['REQUEST_URI'])."\n")
		$check = false;
	}
	if($check){
		$fp = fopen("badlink.txt","a");//badlink.txt就是在网站根目录的记录死链的文件
		flock ($fp, LOCK_EX) ;
		fwrite ($fp, home_url($_SERVER['REQUEST_URI'])."\n");
		flock ($fp, LOCK_UN);
		fclose ($fp);
	}
}
?>
<div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="content-area">
          <main class="site-main">
            <?php if ( have_posts() ) : ?>
              <div class="row posts-wrapper">
                <?php while ( have_posts() ) : the_post();
                  get_template_part( 'parts/template-parts/content', _cao( 'latest_layout', 'grid' ) );
                endwhile; ?>
              </div>
              <?php get_template_part( 'parts/pagination' ); ?>
            <?php else : ?>
              <?php get_template_part( 'parts/template-parts/content', 'none' ); ?>
            <?php endif; ?>
          </main>
        </div>
      </div>
    </div>
</div>

<?php
wp_reset_postdata();
get_footer();
