<?php 

echo '<div id="zk_yyz">'._cao('post_copyright').'<br/></div><div class="entry-links"><a href="'.get_bloginfo('url').'">'.get_bloginfo('name').'</a> &raquo; <a href="'.get_permalink().'">'.get_the_title().'</a><div>';
?>


